<?php
/*
Plugin Name: Himetane Discord Publisher
Description: 自動でWordPressの記事公開をDiscordに通知するプラグイン
Version: 1.2.0
Author: Himetane
*/

if (!defined('ABSPATH')) {
    exit;
}

/**
 * プラグインの設定ページを「設定」メニューに追加します。
 */
function himetane_discord_add_settings_page() {
    add_options_page(
        'Himetane Discord Publisher 設定',
        'Himetane Discord',
        'manage_options',
        'himetane-discord-publisher',
        'himetane_discord_render_settings_page_content'
    );
}
add_action('admin_menu', 'himetane_discord_add_settings_page');

/**
 * 設定ページのHTMLコンテンツをレンダリングします。
 */
function himetane_discord_render_settings_page_content() {
    ?>
    <div class="wrap">
        <h1>Himetane Discord Publisher 設定</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('himetane_discord_options_group');
            do_settings_sections('himetane-discord-publisher');
            submit_button('設定を保存');
            ?>
        </form>
    </div>
    <?php
}

/**
 * プラグイン設定を登録します（設定項目、セクション、フィールド）。
 */
function himetane_discord_register_plugin_settings() {
    register_setting(
        'himetane_discord_options_group',
        'himetane_discord_webhook_url',
        [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]
    );

    add_settings_section(
        'himetane_discord_main_section',
        'Discord Webhook 設定',
        null,
        'himetane-discord-publisher'
    );

    add_settings_field(
        'himetane_discord_webhook_url_field',
        'Webhook URL',
        'himetane_discord_webhook_url_field_callback',
        'himetane-discord-publisher',
        'himetane_discord_main_section'
    );
}
add_action('admin_init', 'himetane_discord_register_plugin_settings');

/**
 * Webhook URL入力フィールドのHTMLを出力するコールバック関数。
 */
function himetane_discord_webhook_url_field_callback() {
    $webhook_url = get_option('himetane_discord_webhook_url');
    echo '<input type="text" id="himetane_discord_webhook_url_field" name="himetane_discord_webhook_url" value="' . esc_attr($webhook_url) . '" size="80" class="regular-text" placeholder="https://discord.com/api/webhooks/your/webhook_url">';
    echo '<p class="description">ここにDiscordチャンネルのWebhook URLを入力してください。Webhook URLはDiscordのチャンネル設定から取得できます。</p>';
}

/**
 * プラグイン有効化時の処理
 */
function himetane_discord_publisher_activation_stub() {
    // 必要であれば、有効化時に実行する処理をここに書きます。
}
register_activation_hook(__FILE__, 'himetane_discord_publisher_activation_stub');

// --- ここからが新しい追加部分 ---

/**
 * Discord通知処理クラスを読み込み、初期化します。
 */
// プラグインのディレクトリパスを取得して、クラスファイルを読み込む
require_once plugin_dir_path(__FILE__) . 'includes/class-himetane-discord-publisher.php';

// クラスが存在するか確認してからインスタンスを作成
if (class_exists('HimetaneDiscordPublisher')) {
    new HimetaneDiscordPublisher();
}

// --- 追加部分ここまで ---

?>
