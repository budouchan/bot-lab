<?php
class HimetaneDiscordPublisher {

    public function __construct() {
        add_action('transition_post_status', [$this, 'handle_post_status_transition'], 10, 3);
    }

    public function handle_post_status_transition($new_status, $old_status, $post) {
        // 新規公開時（既に公開済みの記事を更新した場合は除く）かつ投稿タイプが 'post' の場合のみ処理
        if ($new_status !== 'publish' || $old_status === 'publish' || $post->post_type !== 'post') {
            return;
        }
        $this->send_discord_notification($post);
    }

    private function send_discord_notification($post) {
        // WordPressのオプションからWebhook URLを取得
        $webhook_url = get_option('himetane_discord_webhook_url');

        // Webhook URLが設定されていなければエラーログを残して終了
        if (empty($webhook_url)) {
            error_log('Himetane Discord Publisher: Discord webhook URL is not set in settings.');
            return;
        }

        $post_url = get_permalink($post->ID);
        $post_title = $post->post_title;
        $post_excerpt = $this->get_post_excerpt($post); // 抜粋を取得するメソッドを呼び出し
        $author_name = get_the_author_meta('display_name', $post->post_author);
        $site_name = get_bloginfo('name');
        $thumbnail_url = $this->get_thumbnail_url($post->ID);

        $embed = [
            'title' => $post_title,
            'url' => $post_url,
            'description' => $post_excerpt, // 抜粋を追加
            'color' => hexdec('7E57C2'), // 埋め込みの色 (紫系)
            'author' => [
                'name' => $author_name . ' @ ' . $site_name, // 投稿者名とサイト名
                'icon_url' => get_avatar_url(get_the_author_meta('ID', $post->post_author)) // 投稿者のアバター
            ],
            'footer' => [
                'text' => 'Himetane Discord Publisher',
                'icon_url' => '' // フッターアイコン (必要ならURL指定)
            ],
            'timestamp' => gmdate("c", strtotime($post->post_date_gmt)), // 投稿日時 (ISO8601形式)
        ];

        // サムネイル画像があればembedに追加
        if ($thumbnail_url) {
            $embed['image'] = ['url' => $thumbnail_url];
        }

        $payload = [
            'content' => '記事アップしました！ <@&1145753912725479454> ' . $post_url, // メッセージ内容を少し変更
            'embeds' => [$embed],
            'username' => '記事アップお知らせ君', // Discordに表示されるボット名 (サイト名基準)
            'avatar_url' => 'https://i.imgur.com/G1JeHqo.png',
        ];

        $ch = curl_init($webhook_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10); // タイムアウトを10秒に設定
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); // 接続タイムアウトを5秒に設定

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch); // cURLエラーを取得

        curl_close($ch);

        if ($http_code >= 200 && $http_code < 300) {
            // 成功 (Discordは通常204 No Contentを返す)
            error_log('Himetane Discord Publisher: Notification sent successfully for post ID ' . $post->ID . '. HTTP ' . $http_code);
        } else {
            error_log("Himetane Discord Publisher: Failed to send Discord notification for post ID " . $post->ID . ". HTTP {$http_code}. Response: {$response}. cURL Error: {$curl_error}");
        }
    }

    private function get_thumbnail_url($post_id) {
        if (has_post_thumbnail($post_id)) {
            $thumbnail_id = get_post_thumbnail_id($post_id);
            $thumbnail = wp_get_attachment_image_src($thumbnail_id, 'medium_large'); // 少し大きめのサイズを指定
            return $thumbnail ? $thumbnail[0] : null;
        }
        return null;
    }

    private function get_post_excerpt($post) {
        if (!empty($post->post_excerpt)) {
            return wp_strip_all_tags($post->post_excerpt);
        }
        // 抜粋がなければ本文から自動生成（WordPressの標準的な長さに合わせる）
        $excerpt = wp_strip_all_tags($post->post_content);
        $excerpt = wp_trim_words($excerpt, 55, '...'); // 55単語に丸めて末尾に '...'
        return $excerpt;
    }
}
?>
